package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IGroceryDao;
import com.app.pojos.CartItem;
import com.app.pojos.Category;
import com.app.pojos.Product;
import com.app.pojos.User;

@Service
@Transactional
public class GroceryServiceImpl implements IGroceryService{
	
	@Autowired
	private IGroceryDao dao;
	
	public GroceryServiceImpl() {
		System.out.println("in service implementation...");
	}

	@Override
	public User validate(String email, String password) {
		System.out.println("in service validation...");
		return dao.validate(email, password);
	}

	
	@Override
	public List<User> listUsers() {
		System.out.println("in list users service...");
		return dao.listUsers();
	}

	@Override
	public String deleteUserDetails(int user_id) {
		System.out.println("in delete user service...");
		return dao.deleteUserDetails(dao.getUserDetail(user_id));
	}

	@Override
	public String updateUserDetails(User u) {
		System.out.println("in update user service...");
		return dao.updateUserDetails(u);
	}

	@Override
	public User getUserDetail(int user_id) {
		System.out.println("in get user details service...");
		return dao.getUserDetail(user_id);
	}

	@Override
	public String register(User u) {
		System.out.println("in service register user...");
		return dao.register(u);
	}

	@Override
	public List<Category> listCategory() {
		System.out.println("in list category service...");
		return dao.listCategory();
	}

	@Override
	public String addCategory(Category c) {
		System.out.println("in service add category...");
		return dao.addCategory(c);
	}

	@Override
	public String deleteCategory(int category_id) {
		System.out.println("in delete category service...");
		return dao.deleteCategory(dao.getCategory(category_id));
	}

	@Override
	public String updateCategory(Category c) {
		System.out.println("in update category service...");
		return dao.updateCategory(c);
	}

	@Override
	public Category getCategory(int category_id) {
		System.out.println("in get category details service...");
		return dao.getCategory(category_id);
	}

	@Override
	public List<Product> listProduct() {
		System.out.println("in list product service...");
		return dao.listProduct();
	}


	@Override
	public String deleteProduct(int product_id) {
		System.out.println("in delete product service...");
		return dao.deleteProduct(dao.getProduct(product_id));
	}

	@Override
	public String updateProduct(Product p) {
		System.out.println("in update product service...");
		return dao.updateProduct(p);
	}

	@Override
	public Product getProduct(int prod_id) {
		System.out.println("in service......in get product details service...");
		
		return dao.getProduct(prod_id);
	}

	@Override
	public List<Product> listProductById(int category_id) {
		System.out.println("in get product list by cat_id  service...");
		return dao.listProductById(category_id);
	}

	@Override
	public Category getOb(int category_id) {
		System.out.println("in service getobject by category....");
		return dao.getOb(category_id);
	}

	@Override
	public String addProduct(Product pa) {
		System.out.println("in service add product....");
		return dao.addProduct(pa);
	}

	@Override
	public Product getProd(int prod_id) {
		System.out.println("in service getprod....");
		return dao.getProd(prod_id);
	}

	@Override
	public String addToCartitem(CartItem item) {
		System.out.println("in service addToCartitem....");
		return dao.addToCartitem(item);
	}

	@Override
	public String addQuantity(int quantity) {
		System.out.println("in service addQuantity...");
		return dao.addQuantity(quantity);
	}

	

}
