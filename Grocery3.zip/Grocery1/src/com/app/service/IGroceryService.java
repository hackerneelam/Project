package com.app.service;

import java.util.List;

import com.app.pojos.CartItem;
import com.app.pojos.Category;
import com.app.pojos.Product;
import com.app.pojos.User;

public interface IGroceryService {
	
	//User CRUD
	
	User validate(String email,String password);
	List<User>listUsers();
	String deleteUserDetails(int user_id);
	String updateUserDetails(User u);
	User getUserDetail(int user_id);
	String register(User u);
	
	//Category CRUD
	List<Category>listCategory();
	String addCategory(Category c);
	String deleteCategory(int category_id);
	String updateCategory(Category c);
	Category getCategory(int category_id);
	

	//Product CRUD
	List<Product>listProduct();
	String addProduct(Product pa);
	String deleteProduct(int product_id);
	String updateProduct(Product p);
	Product getProduct(int prod_id);
	List<Product>listProductById(int category_id);
	Category getOb(int category_id);
	
	
	Product getProd(int prod_id);
	String addToCartitem(CartItem item);
	String addQuantity(int quantity);

	
}
