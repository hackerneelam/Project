package com.app.pojos;


import java.util.List;

import javax.persistence.*;
/*import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;*/
import javax.validation.constraints.*;

@Entity
public class User {
	
	public Integer user_id;
	public String name;
	public String email;
	public String password;
	public String contact_no;
	public String role;
	public String address;
	
	public Cart cart;
	public OrderDetails Orderdetails;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getUser_id() {
		return user_id;
	}
	
	
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	
	@Column(length=20)
	//@NotNull(message = "This field is mandatory!")
	public String getName() {
		return name;
	}
	
	
	public void setName(String name) {
		this.name = name;
	}
	
	@Column(length=20,unique = true)
	//@NotNull(message = "This field is mandatory!")
	public String getEmail() {
		return email;
	}
	
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	//@Size(min = 5, max = 8)
	//@Pattern(regexp="^[a-zA-Z0-9]")  
	//@NotNull(message = "This field is mandatory!")
	public String getPassword() {
		return password;
	}
	
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Column
	public String getContact_no() {
		return contact_no;
	}
	
	
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	
	@Column(length=10)
	public String getRole() {
		return role;
	}
	
	
	public void setRole(String role) {
		this.role = role;
	}
	
	
	 
	 
		
		public String getAddress() {
			return address;
		}


		public void setAddress(String address) {
			this.address = address;
		}

		
	@OneToOne(mappedBy = "user")
	public Cart getCart() {
			return cart;
		}


		public void setCart(Cart cart) {
			this.cart = cart;
		}

		
		
		
		
		
		
	@OneToOne(mappedBy = "user")
	public OrderDetails getOrderdetails() {
			return Orderdetails;
		}


		public void setOrderdetails(OrderDetails orderdetails) {
			Orderdetails = orderdetails;
		}


	public User() {
		System.out.println("in user's default consructor...");
	}

	
	
	

	public User(String name, String email, String password, String contact_no, String role, String address,
			 Cart cart, OrderDetails orderdetails) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.contact_no = contact_no;
		this.role = role;
		this.address = address;
		this.cart = cart;
		Orderdetails = orderdetails;
	}


	
	
	@Override
	public String toString() {
		return "User [user_id=" + user_id + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", contact_no=" + contact_no + ", role=" + role + ", address=" + address 
				+ ", cart=" + cart + ", Orderdetails=" + Orderdetails + "]";
	}


	
	


	

}
