package com.app.pojos;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GeneratorType;

@Entity
public class BillGeneration {

	public Integer bill_id;
	public String order_status;
	public String billing_status;
	public OrderDetails orderdetails;

	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer getBill_id() {
		return bill_id;
	}
	public void setBill_id(Integer bill_id) {
		this.bill_id = bill_id;
	}
	

	public String getOrder_status() {
		return order_status;
	}
	public void setOrder_status(String order_status) {
		this.order_status = order_status;
	}
	
	
	public String getBilling_status() {
		return billing_status;
	}
	public void setBilling_status(String billing_status) {
		this.billing_status = billing_status;
	}
	
	
	
	@OneToOne
	@JoinColumn(name="detail_id")
	public OrderDetails getOrderdetails() {
		return orderdetails;
	}
	public void setOrderdetails(OrderDetails orderdetails) {
		this.orderdetails = orderdetails;
	}
	
	
	public BillGeneration(String order_status, String billing_status, OrderDetails orderdetails) {
		super();
		this.order_status = order_status;
		this.billing_status = billing_status;
		this.orderdetails = orderdetails;
	}
	
	
	@Override
	public String toString() {
		return "BillGeneration [bill_id=" + bill_id + ", order_status=" + order_status + ", billing_status="
				+ billing_status + ", orderdetails=" + orderdetails + "]";
	}

	
	
	
	
	
	
	
}
