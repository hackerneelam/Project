package com.app.pojos;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
public class OrderDetails {
	
	public Integer detail_id;
	public int quantity;
	public int price;
	
	public User user;
	public Category category;
	public Orders order;
	public BillGeneration bill;

	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getDetail_id() {
		return detail_id;
	}
	public void setDetail_id(Integer detail_id) {
		this.detail_id =detail_id;
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	 @OneToOne
	 @JoinColumn(name="orderr_id")	 
	public Orders getOrder() {
		return order;
	}
	public void setOrder(Orders order) {
		this.order = order;
	}
	
	
	@OneToOne
	@JoinColumn(name="user_id")
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	@OneToOne
	@JoinColumn(name="order_id")
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}

	
	
	@OneToOne(mappedBy = "orderdetails")
	public BillGeneration getBill() {
		return bill;
	}
	public void setBill(BillGeneration bill) {
		this.bill = bill;
	}
	
	
	
	public OrderDetails(int quantity, int price, User user, Category category, Orders order, BillGeneration bill) {
		super();
		this.quantity = quantity;
		this.price = price;
		this.user = user;
		this.category = category;
		this.order = order;
		this.bill = bill;
	}
	
	
	public OrderDetails()
	{
		System.out.println("in order default constructor...");
	}
	
	
	
	@Override
	public String toString() {
		return "OrderDetails [detail_id=" + detail_id + ", quantity=" + quantity + ", price=" + price + ", user=" + user
				+ ", category=" + category + ", order=" + order + ", bill=" + bill + "]";
	}
	
	
	
	
	
	

}
