package com.app.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
public class CartItem {
	public Integer cartItem_id;
	public int quantity;
	public float totalPrice;

	public Product product;
	public Cart cart;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getCartItem_id() {
		return cartItem_id;
	}

	public void setCartItem_id(Integer cartItem_id) {
		this.cartItem_id = cartItem_id;
	}

	@ManyToOne
	@JoinColumn(name = "cart_id")
	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}

	@ManyToOne
	@JoinColumn(name = "prod_id")
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public CartItem() {
		System.out.println("In cartItems def contr pojo...");
	}

	public CartItem(Product product, Cart cart, int quantity, float totalPrice) {
		super();
		this.product = product;
		this.cart = cart;
		this.quantity = quantity;
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return "CartItem [cartItem_id=" + cartItem_id + ", product=" + product + ", cart=" + cart + ", quantity="
				+ quantity + ", totalPrice=" + totalPrice + "]";
	}

}
