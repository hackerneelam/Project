	package com.app.pojos;
	
	import java.util.List;
	
	import javax.persistence.CascadeType;
	import javax.persistence.Entity;
	import javax.persistence.FetchType;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.JoinColumn;
	import javax.persistence.OneToMany;
	import javax.persistence.OneToOne;
	import javax.persistence.Table;
	
	
	@Entity
	
	public class Cart {
	public Integer cart_id;
	public float grand_total;
	
	public List<CartItem> cart_items;
	public User user;
	public Orders order2;
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getCart_id() {
		return cart_id;
	}
	
	
	public void setCart_id(Integer cart_id) {
		this.cart_id = cart_id;
	}
	
	
	
	
	@OneToMany(mappedBy = "cart",cascade = CascadeType.ALL)
	public List<CartItem> getCart_items() {
		return cart_items;
	}
	
	
	public void setCart_items(List<CartItem> cart_items) {
		this.cart_items = cart_items;
	}
	
	@OneToOne
	@JoinColumn(name="user_id")
	public User getUser() {
		return user;
	}
	
	
	public void setUser(User user) {
		this.user = user;
	}
	
	
	public float getGrand_total() {
		return grand_total;
	}
	
	
	public void setGrand_total(float grand_total) {
		this.grand_total = grand_total;
	}
	
	
	
	
	@OneToOne(mappedBy = "cart")
	public Orders getOrder() {
		return order2;
	}
	
	
	public void setOrder(Orders order) {
		this.order2 = order;
	}
	
	
	public Cart() {
		System.out.println("in def constr of cart pojo ...");
	}
	
	
	public Cart(float grand_total, List<CartItem> cart_items, User user, Orders order) {
		super();
		this.grand_total = grand_total;
		this.cart_items = cart_items;
		this.user = user;
		this.order2 = order;
	}
	
	
	@Override
	public String toString() {
		return "Cart [cart_id=" + cart_id + ", grand_total=" + grand_total + ", cart_items=" + cart_items + ", user=" + user
				+ ", order=" + order2 + "]";
	}
	
	
	
	
	
	
	}
