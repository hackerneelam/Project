package com.app.pojos;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GeneratorType;

import com.sun.prism.Image;

@Entity
public class Product {

	public Integer prod_id;
	public String prod_name;
	public String quantity;
	public double price;
	public Image image;
	public int stock;
	
	public Category cat;
	
	
	public List<CartItem> cartitem;
	
	public Product() {
		System.out.println("in product default constructor...");
	}
	
	public Product(String prod_name,double price,int stock)
	{
		this.prod_name = prod_name;
		this.price = price;
		this.stock=stock;
		System.out.println("in product insert...");
		
	}
	
	
	public Product(String prod_name, String quantity, double price, Image image, int stock, Category cat,
			List<CartItem> cartitem) {
		super();
		this.prod_name = prod_name;
		this.quantity = quantity;
		this.price = price;
		this.image = image;
		this.stock = stock;
		this.cat = cat;
		this.cartitem = cartitem;
	}
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getProd_id() {
		return prod_id;
	}
	public void setProd_id(Integer prod_id) {
		this.prod_id = prod_id;
	}
	
	
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	
	
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	@Lob
	public Image getImage() {
		return image;
	}
	public void setImage(Image image) {
		this.image = image;
	}
	
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	
	
	@ManyToOne
	@JoinColumn(name="category_id")
	public Category getCat() {
		return cat;
	}
	public void setCat(Category cat) {
		this.cat = cat;
	}
	
	
	
	@OneToMany(mappedBy="product",cascade = CascadeType.ALL)
	public List<CartItem> getCartitem() {
		return cartitem;
	}
	public void setCartitem(List<CartItem> cartitem) {
		this.cartitem = cartitem;
	}
	
	
	/*
	 * @Override public String toString() { return "Product [prod_id=" + prod_id +
	 * ", prod_name=" + prod_name + ", quantity=" + quantity + ", price=" + price +
	 * ", image=" + image + ", stock=" + stock + ", cat=" + cat + ", cartitem=" +
	 * cartitem + "]"; }
	 */
	
	
	
} 
