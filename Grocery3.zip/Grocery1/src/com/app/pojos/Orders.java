package com.app.pojos;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
public class Orders {
	
	public Integer order_id;
	public Date order_date;
	public Date shipment_date;
	public String order_status;
	
	public OrderDetails orderdetails;
	public Cart cart;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getOrder_id() {
		return order_id;
	}
	public void setOrder_id(Integer order_id) {
		this.order_id = order_id;
	}
	public Date getOrder_date() {
		return order_date;
	}
	public void setOrder_date(Date order_date) {
		this.order_date = order_date;
	}
	public Date getShipment_date() {
		return shipment_date;
	}
	public void setShipment_date(Date shipment_date) {
		this.shipment_date = shipment_date;
	}
	public String getOrder_status() {
		return order_status;
	}
	public void setOrder_status(String order_status) {
		this.order_status = order_status;
	}
	
	
	
	@OneToOne(mappedBy="order",cascade = CascadeType.ALL) 
	public OrderDetails getOrderdetails() {
		return orderdetails;
	}
	public void setOrderdetails(OrderDetails orderdetails) {
		this.orderdetails = orderdetails;
	}
	
	
	
	

	@OneToOne
	@JoinColumn(name="cart_id")
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	
	
	
	public Orders()
	{
		System.out.println("in orders...");
	}
	
	
	
	public Orders(Date order_date, Date shipment_date, String order_status, OrderDetails orderdetails,
			BillGeneration billgeneration, Cart cart) {
		super();
		this.order_date = order_date;
		this.shipment_date = shipment_date;
		this.order_status = order_status;
		this.orderdetails = orderdetails;
		this.cart = cart;
	}
	
	
	
	@Override
	public String toString() {
		return "Orders [order_id=" + order_id + ", order_date=" + order_date + ", shipment_date=" + shipment_date
				+ ", order_status=" + order_status + ", orderdetails=" + orderdetails + ", cart=" + cart + "]";
	}

		
	
	
}
