package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Cart;
import com.app.pojos.CartItem;
import com.app.pojos.Category;
import com.app.pojos.Product;
import com.app.pojos.User;
import com.mysql.cj.Session;
import com.sun.prism.Image;

@Repository
public class GroceryDaoImpl implements IGroceryDao{

	@Autowired
	private SessionFactory sf;

	
	
	//User CRUD
	
	@Override
	public User validate(String email, String password) {
		String jpql="select u from User u where u.email=:em and u.password=:pass";
		return sf.getCurrentSession().createQuery(jpql,User.class).
				setParameter("em", email).
				setParameter("pass", password).
				getSingleResult();
	}
		
	
	
	@Override
	public String register(User u) {
		  System.out.println("In dao's registration...");
		  sf.getCurrentSession().persist(u); 
		  return "User details inserted successfully for User ID"+u.getUser_id();
	}
	
	

	@Override
	public List<User> listUsers() {
		System.out.println("in list user details...");
		String jpql="select u from User u where u.role=:role";
		return sf.getCurrentSession()
				.createQuery(jpql,User.class)
				.setParameter("role", "user")
				.getResultList();
	}

	@Override
	public String deleteUserDetails(User u) {
		System.out.println("in delete user...");
		sf.getCurrentSession().delete(u);
		return "User details deleted for user id"+u.getUser_id()+"successfully...";
	}

	@Override
	public String updateUserDetails(User u) {
		System.out.println("in update user...");
		sf.getCurrentSession().update(u);
		return "User details updated for user id"+u.getUser_id()+"successfully...";
	}

	@Override
	public User getUserDetail(int user_id) {
		System.out.println("in get user details...");
		return sf.getCurrentSession().get(User.class, user_id);
	}


	
	
	//Category CRUD

	@Override
	public List<Category> listCategory() {
		System.out.println("in list categories...");
		String jpql="select c from Category c";
		return sf.getCurrentSession()
				.createQuery(jpql,Category.class)
				.getResultList();
	}



	@Override
	public String addCategory(Category c) {
		System.out.println("In dao's add category...");
		  sf.getCurrentSession().persist(c); 
		  return "Category added successfully for Category ID"+c.getCategory_id();
	}



	@Override
	public String deleteCategory(Category c) {
		System.out.println("in delete category...");
		sf.getCurrentSession().delete(c);
		return "Category deleted for category id"+c.getCategory_id()+"successfully...";
	}



	@Override
	public String updateCategory(Category c) {
		System.out.println("in update category...");
		sf.getCurrentSession().update(c);
		return "Category details updated for category id"+c.getCategory_id()+"successfully...";
	}



	@Override
	public Category getCategory(int category_id) {
		System.out.println("in get category details...");
		return sf.getCurrentSession().get(Category.class, category_id);
	}
	
	
	

	//Product CRUD

	@Override
	public List<Product> listProduct() {
		System.out.println("in list products...");
		String jpql="select p from Product p";
		List<Product> pr=sf.getCurrentSession()
				.createQuery(jpql,Product.class)
				.getResultList();
		System.out.println("product listsssssss"+pr);
		return pr;
	}



	@Override
	public String deleteProduct(Product p) {
		System.out.println("in delete product...");
		sf.getCurrentSession().clear();
		sf.getCurrentSession().delete(p);
		return "product deleted for product id"+p.getProd_id()+"successfully...";
	}



	@Override
	public String updateProduct(Product p) {
		System.out.println("in update product...");
		//sf.getCurrentSession().clear();
		sf.getCurrentSession().update(p);
		return "product details updated for product id"+p.getProd_id()+"successfully...";
	}



	@Override
	public Product getProduct(int prod_id) {
		System.out.println("in dao............ get product details...myid");
		String jpql="select p from Product p where p.prod_id=:prod_id";
		  return sf.getCurrentSession() .createQuery(jpql,Product.class)
		  .setParameter("prod_id", prod_id) .getSingleResult();
		 
		
	}



	@Override
	public List<Product> listProductById(int category_id) {
		System.out.println("in get product by category id dao...");
		String jpql="select p from Product p where category_id=:category_id";
		return sf.getCurrentSession()
				.createQuery(jpql,Product.class)
				.setParameter("category_id", category_id)
				.getResultList();	}



	@Override
	public Category getOb(int category_id) {
		System.out.println("in dao's getobject by category...");
		return sf.getCurrentSession().get(Category.class, category_id);
	}
	@Override
	public String addProduct(Product prod) {
		System.out.println("in dao's add product....");
		sf.getCurrentSession().save(prod);
		return "success";
	}

	@Override
	public Product getProd(int prod_id)
	{
		System.out.println("in dao getProd.... ");
		return sf.getCurrentSession().get(Product.class, prod_id);
	}
	
	
	@Override
	  public String addToCartitem(CartItem item) {
		  sf.getCurrentSession().save(item);
	  
	 return "success";
	  
	  }



	@Override
	public String addQuantity(int quantity) {
		System.out.println("in dao addQuantity...");
		String jpql="alter table CartItem set quantity=:quantity";
		sf.getCurrentSession().createQuery(jpql, CartItem.class).setParameter("quantity", quantity).getSingleResult();
		return "success";
	}
	
	

	
}
