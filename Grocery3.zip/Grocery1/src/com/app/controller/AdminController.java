package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Category;
import com.app.pojos.Product;
import com.app.pojos.User;
import com.app.service.IGroceryService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private IGroceryService service;
	
	public AdminController()
	{
		System.out.println("in admin controller...");
	}
	

	
	  @GetMapping("/home") 
	  public String adminHome() 
	  { 
		  return "/admin/home";
	  }
	  
	  
	  //User CRUD
	
	@GetMapping("/list")
	public String showUsersList(Model map)
	{
		System.out.println("in listuser admin controller...");
		map.addAttribute("user_list",service.listUsers());
		return "/admin/list";
	}
	
	
	
	@GetMapping("/update")
	public String showUpdateForm(@RequestParam int user_id,Model map)
	{
		System.out.println("in show update form ");
		map.addAttribute("user",service.getUserDetail(user_id));
		//System.out.println(map);
		return "/admin/update";
	}
	
	@PostMapping("/update")
	public String processUpdateForm(User u,RedirectAttributes flashMap)
	{
		System.out.println("in process update "+u);
		flashMap.addFlashAttribute("status", service.updateUserDetails(u));
		return "redirect:/admin/list";
	}
	
	
	
	@GetMapping("/delete")
	public String deleteUser(@RequestParam int user_id,
								RedirectAttributes flashmap)
	{
		System.out.println("in deleteuser admin controller...");
		flashmap.addFlashAttribute("status",service.deleteUserDetails(user_id));
		return "redirect:/admin/list";
	}
	
	
	
	//Category CRUD
	
	@GetMapping("/categorylist")
	public String showCategoryList(Model map)
	{
		System.out.println("in categorylist admin controller...");
		map.addAttribute("category_list",service.listCategory());
		return "/admin/categorylist";
	}
	
	
	
	@GetMapping("/updatecat")
	public String showUpdateCategoryForm(@RequestParam int category_id,RedirectAttributes flashMap)
	{
		System.out.println("in show update category form ");
		flashMap.addFlashAttribute("category",service.getCategory(category_id));
		//System.out.println(map);
		return "/admin/updatecat";
	}
	
	@PostMapping("/updatecat")
	public String processUpdateCategoryForm(Category c,RedirectAttributes flashMap)
	{
		System.out.println("in process update category "+c);
		flashMap.addFlashAttribute("status", service.updateCategory(c));
		return "redirect:/admin/categorylist";
	}
	
	
	@GetMapping("/deletecat")
	public String deleteCat(@RequestParam int category_id,
								RedirectAttributes flashmap)
	{
		System.out.println("in deletecategory admin controller...");
		flashmap.addFlashAttribute("status",service.deleteCategory(category_id));
		return "redirect:/admin/categorylist";
	}
	
	
	
	//Product CRUD
	
	@GetMapping("/productlist")
	public String showProductList(RedirectAttributes flashmap,HttpSession hs)
	{
		System.out.println("in productlist admin controller...");
		hs.setAttribute("product_det", service.listProduct());
		flashmap.addFlashAttribute("product_list",service.listProduct());
		System.out.println("asgdsad"+flashmap);
		return "/admin/productlist";
	}
	
	@GetMapping("/updateprod")
	public String showUpdateProductForm(@RequestParam int prod_id,Model map,HttpSession hs)
	{
		System.out.println("in show update product form ");
		
		hs.setAttribute("product",service.getProd(prod_id));
		map.addAttribute("product",service.getProd(prod_id));
		//System.out.println(map);
		return "/admin/updateprod";
	}
	
	@PostMapping("/updateprod")
	public String processUpdateProductForm(Product p,RedirectAttributes flashMap)
	{
		System.out.println("in process update product "+p);
		flashMap.addFlashAttribute("status", service.updateProduct(p));
		return "redirect:/admin/productlist";
	}
	
	
	@GetMapping("/deleteprod")
	public String deleteprod(@RequestParam int prod_id,
								RedirectAttributes flashmap)
	{
		System.out.println("in delete product admin controller...");
		flashmap.addFlashAttribute("status",service.deleteProduct(prod_id));
		return "redirect:/admin/productlist";
	}
	
	@GetMapping("/addcategory")
	public String addCategory(Category c)
	{
		System.out.println("in add category...");
		return "/admin/addcategory";
	}
	
	@PostMapping("/addcategory")
	public String addCategoryByAdmin(Category c,RedirectAttributes flashmap)
	{
		System.out.println("in add category by admin...");
		flashmap.addFlashAttribute("status",service.addCategory(c));
		return "redirect:/admin/categorylist";
	}
	
	@GetMapping("/addproduct")
	public String addProduct(Product p)
	{
		System.out.println("in add product...");
		return "/admin/addproduct";
	}
	
	@PostMapping("/addproduct")
	public String addProductByAdmin(Product p,RedirectAttributes flashmap,@RequestParam int category_id)
	{
		Category c=service.getOb(category_id);
		Product prod=null;
		prod=p;
		prod.setCat(c);
		System.out.println("in add product by admin...");
		flashmap.addFlashAttribute("status",service.addProduct(prod));
		return "redirect:/admin/productlist";
	}
	
}
