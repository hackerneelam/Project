package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Cart;
import com.app.pojos.CartItem;
import com.app.pojos.Category;
import com.app.pojos.Product;
import com.app.pojos.User;
import com.app.service.IGroceryService;

import antlr.Parser;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private IGroceryService service;

	public UserController() {
		System.out.println("in user controller...");
	}

	@GetMapping("/login")
	public String showLoginForm() {
		System.out.println("in show login form...");
		return "/user/login";
	}

	@PostMapping("/login")
	public String processLoginForm(Model map, @RequestParam String email, @RequestParam String password,
			HttpSession hs) {
		System.out.println("in process login form...");
		try {
			User use = service.validate(email, password);
			map.addAttribute("status", "login successfully...");
			hs.setAttribute("user_details", use);

			if (use != null) {
				if ((use.getEmail().equals("sai@gmail")) && (use.getPassword().equals("sai@123"))) {

					return "redirect:/admin/home";

				} else {
					return "/user/details";
				}

			} else {
				return "/user/login";
			}

		} catch (RuntimeException e) {
			System.out.println("err in user controller " + e);
			map.addAttribute("status", "Invalid Login , Pls retry!!!!");
			return "/user/login";
		}

	}

	@GetMapping("/register")
	public String showRegForm(User u) {
		System.out.println("in show register form...");
		return "/user/register";
	}

	@PostMapping("/register")
	public String processRegForm(User u, RedirectAttributes flashmap) {
		System.out.println("in process login form...");
		// User u1=new User();
		// flashmap.addFlashAttribute("status",service.addUser(u1));
		flashmap.addFlashAttribute("status", service.register(u));
		return "redirect:/user/login";

	}

	@GetMapping("/logout")
	public String userLogout(HttpSession hs, Model map, HttpServletRequest request, HttpServletResponse response) {
		System.out.println("in user logout...");
		map.addAttribute("details", hs.getAttribute("user_details"));
		hs.invalidate();
		response.setHeader("refresh", "5;url=" + request.getContextPath());
		return "/user/logout";
	}

	@GetMapping("/category")
	public String showcategory(Model map) {
		System.out.println("in user show category");
		map.addAttribute("category_list", service.listCategory());
		return "/user/categorylist";
	}

	@GetMapping("/product")
	public String showProduct(@RequestParam int category_id, Model map) {

		System.out.println("in product user controller...");
		map.addAttribute("product_list", service.listProductById(category_id));
		return "/user/productlist";
	}

	@GetMapping("/prod_details")
	public String productDetails(@RequestParam int prod_id, Model map, HttpSession hs) {
		System.out.println("in user.............. controller get product details...");
		
		Product p=service.getProduct(prod_id);
		//flashmap.addFlashAttribute("product_details", service.getProduct(prod_id));
		//map.addAttribute("pro_de", service.getProduct(prod_id));
		hs.setAttribute("product_details",p);
		// map.addAttribute("product_details",service.getProduct(prod_id));
		return "/user/prod_detailsPage";

	}

	/*
	 * @GetMapping("/prod_details") public String productDetails(@RequestParam int
	 * prod_id,Model map) {
	 * System.out.println("in user controller get product details...");
	 * map.addAttribute("product_details",service.getProduct(prod_id)); return
	 * "/user/prod_details"; }
	 */

	@GetMapping("/addToCart")
	public String addToCartItem(CartItem item, RedirectAttributes flashmap,@RequestParam int prod_id,@RequestParam int quantity) {
		Product pro = service.getProduct(prod_id);
		CartItem i = null;
		i = item;
		i.setProduct(pro);
		i.setQuantity(quantity);
		System.out.println("quantity:"+quantity);
		System.out.println("in add addToCartItem...");
		flashmap.addFlashAttribute("status", service.addToCartitem(i));
		return "/user/cart";

	}
	
	/*
	 * @PostMapping("/addToCart") public String adddToCart(@RequestParam int
	 * quantity) { System.out.println("quantity" + quantity);
	 * 
	 * return "redirect:/user/cart"; }
	 */

}
